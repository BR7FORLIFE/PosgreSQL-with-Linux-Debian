package com.archives.crudtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudtaskApplication.class, args);
	}

}
